const REJECTED_KEYS = new Set([
  'tracking_number', 'shipper_address', 'recipient_address', 'misc_info',
  'customer_number', 'reference_number', 'local_number', 'email', 'user_id', 'ip',
]);

export function walkReject(obj: unknown): string | null {
  if (obj === null || typeof obj !== 'object') return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const hit = walkReject(item);
      if (hit) return hit;
    }
    return null;
  }
  for (const key of Object.keys(obj as Record<string, unknown>)) {
    if (REJECTED_KEYS.has(key)) return key;
    const hit = walkReject((obj as Record<string, unknown>)[key]);
    if (hit) return hit;
  }
  return null;
}
