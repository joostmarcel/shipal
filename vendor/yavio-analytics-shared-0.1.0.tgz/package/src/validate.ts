import { Ajv } from 'ajv';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const envelopeSchema = require('./schemas/v1/envelope.json');
// ajv-formats ships only a CJS default export; under NodeNext the namespace
// import is not callable. Resolve via require to get the function value.
const addFormatsMod = require('ajv-formats') as unknown;
const addFormats = ((addFormatsMod as { default?: (a: Ajv) => Ajv }).default
  ?? (addFormatsMod as (a: Ajv) => Ajv));

const ajv = new Ajv({ strict: false });
addFormats(ajv);
const validateEnvelope = ajv.compile(envelopeSchema);

export interface ValidationResult {
  valid: boolean;
  errors?: string;
}

export function validateBatch(body: unknown): ValidationResult {
  const valid = validateEnvelope(body) as boolean;
  if (!valid) return { valid: false, errors: ajv.errorsText(validateEnvelope.errors) };
  return { valid: true };
}
