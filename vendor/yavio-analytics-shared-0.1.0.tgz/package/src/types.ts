export interface Envelope {
  events: Event[];
  sdk_version: string;
  sent_at: string;
  schema_version: 'v1';
}

export interface Event {
  event_id: string;
  ts: string;
  event_name: string;
  source: 'server' | 'widget' | 'explicit';
  session_id?: string;
  trace_id?: string;
  tool_name?: string;
  tool_status?: string;
  error_code?: string;
  latency_ms?: number;
  user_intent?: string;
  user_intent_detail?: string;
  funnel_name?: string;
  funnel_step?: string;
  conversion_value?: number;
  conversion_currency?: string;
  widget_element?: string;
  widget_event_key?: string;
  app_version?: string;
  properties?: Record<string, unknown>;
}

export type EventName =
  | 'tool_call' | 'connection' | 'resource_access' | 'prompt_usage'
  | 'sampling_call' | 'elicitation' | 'widget_response' | 'tool_discovery'
  | 'widget_click' | 'widget_scroll' | 'widget_form_submit' | 'widget_form_abandon'
  | 'widget_rage_click' | 'widget_performance' | 'widget_pageview'
  | 'track' | 'step' | 'conversion';
