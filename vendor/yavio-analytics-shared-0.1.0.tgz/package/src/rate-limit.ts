export interface RateLimitOptions {
  capacity: number;
  windowMs: number;
}

export interface RateLimitResult {
  ok: boolean;
  retryAfterSeconds: number;
}

interface Bucket {
  tokens: number;
  lastRefill: number;
}

export interface RateLimiter {
  check(key: string): RateLimitResult;
}

export function createRateLimiter(opts: RateLimitOptions): RateLimiter {
  const { capacity, windowMs } = opts;
  const refillPerMs = capacity / windowMs;
  const buckets = new Map<string, Bucket>();
  const cleanupEvery = Math.max(windowMs, 60_000);

  const timer = setInterval(() => {
    const cutoff = Date.now() - windowMs * 2;
    for (const [k, b] of buckets) if (b.lastRefill < cutoff) buckets.delete(k);
  }, cleanupEvery);
  timer.unref?.();

  return {
    check(key: string): RateLimitResult {
      const now = Date.now();
      let bucket = buckets.get(key);
      if (!bucket) {
        bucket = { tokens: capacity, lastRefill: now };
        buckets.set(key, bucket);
      } else {
        const elapsed = now - bucket.lastRefill;
        bucket.tokens = Math.min(capacity, bucket.tokens + elapsed * refillPerMs);
        bucket.lastRefill = now;
      }
      if (bucket.tokens < 1) {
        return {
          ok: false,
          retryAfterSeconds: Math.ceil((1 - bucket.tokens) / refillPerMs / 1000),
        };
      }
      bucket.tokens -= 1;
      return { ok: true, retryAfterSeconds: 0 };
    },
  };
}
