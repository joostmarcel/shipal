import { describe, it, expect } from 'vitest';
import { validateBatch } from '../src/validate.js';

const valid = {
  events: [{ event_id: 'e1', ts: '2026-04-24T10:00:00Z', event_name: 'tool_call', source: 'server' }],
  sdk_version: 'yavio-analytics-0.1.0',
  sent_at: '2026-04-24T10:00:00Z',
  schema_version: 'v1',
};

describe('validateBatch', () => {
  it('accepts a minimal valid envelope', () => {
    expect(validateBatch(valid).valid).toBe(true);
  });
  it('rejects missing top-level "events" field', () => {
    const { events: _, ...noEvents } = valid;
    expect(validateBatch(noEvents).valid).toBe(false);
  });
  it('rejects empty events array', () => {
    expect(validateBatch({ ...valid, events: [] }).valid).toBe(false);
  });
  it('rejects invalid schema_version', () => {
    expect(validateBatch({ ...valid, schema_version: 'v2' }).valid).toBe(false);
  });
  it('rejects event missing required "source" field', () => {
    const badEvent = { event_id: 'e1', ts: '2026-04-24T10:00:00Z', event_name: 'tool_call' };
    expect(validateBatch({ ...valid, events: [badEvent] }).valid).toBe(false);
  });
  it('rejects event with invalid source value', () => {
    expect(validateBatch({ ...valid, events: [{ ...valid.events[0], source: 'mobile' }] }).valid).toBe(false);
  });
  it('accepts envelope with all optional event fields', () => {
    const rich = {
      ...valid.events[0],
      session_id: 's1', trace_id: 't1', tool_name: 'search',
      latency_ms: 250, user_intent: 'find package', properties: { carrier: 'DHL' },
    };
    expect(validateBatch({ ...valid, events: [rich] }).valid).toBe(true);
  });
  it('rejects non-object input', () => {
    expect(validateBatch('not-an-object').valid).toBe(false);
  });
});
