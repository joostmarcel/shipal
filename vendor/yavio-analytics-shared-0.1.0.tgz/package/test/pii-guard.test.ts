import { describe, it, expect } from 'vitest';
import { walkReject } from '../src/pii-guard.js';

describe('walkReject', () => {
  it('returns null for a clean event', () => {
    expect(walkReject({ tool_name: 'search', session_id: 'abc', trace_id: 'xyz' })).toBeNull();
  });
  it('detects a top-level rejected key', () => {
    expect(walkReject({ email: 'user@example.com', tool_name: 'search' })).toBe('email');
  });
  it('detects a nested rejected key', () => {
    expect(walkReject({ properties: { user_id: '123', count: 5 } })).toBe('user_id');
  });
  it('detects a rejected key inside an array element', () => {
    expect(walkReject({ events: [{ tool_name: 'a' }, { ip: '1.2.3.4' }] })).toBe('ip');
  });
  it('allows whitelisted abstraction fields', () => {
    expect(walkReject({ user_intent: 'find package', user_intent_detail: 'ETA' })).toBeNull();
  });
  it('rejects all 10 reserved keys individually', () => {
    const keys = [
      'tracking_number', 'shipper_address', 'recipient_address', 'misc_info',
      'customer_number', 'reference_number', 'local_number', 'email', 'user_id', 'ip',
    ];
    for (const k of keys) {
      expect(walkReject({ [k]: 'value' }), `failed for key "${k}"`).toBe(k);
    }
  });
  it('handles deeply nested objects (3+ levels)', () => {
    expect(walkReject({ a: { b: { c: { email: 'x' } } } })).toBe('email');
  });
  it('returns null for non-objects (string, number, null)', () => {
    expect(walkReject('hello')).toBeNull();
    expect(walkReject(42)).toBeNull();
    expect(walkReject(null)).toBeNull();
  });
});
