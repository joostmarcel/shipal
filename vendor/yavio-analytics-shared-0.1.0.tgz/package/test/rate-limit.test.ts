import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { createRateLimiter } from '../src/rate-limit.js';

describe('createRateLimiter', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-04-28T00:00:00Z'));
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it('allows up to capacity requests in the window', () => {
    const rl = createRateLimiter({ capacity: 3, windowMs: 60_000 });
    expect(rl.check('a').ok).toBe(true);
    expect(rl.check('a').ok).toBe(true);
    expect(rl.check('a').ok).toBe(true);
    expect(rl.check('a').ok).toBe(false);
  });

  it('returns retryAfterSeconds when blocked', () => {
    const rl = createRateLimiter({ capacity: 1, windowMs: 60_000 });
    rl.check('a');
    const blocked = rl.check('a');
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfterSeconds).toBeGreaterThan(0);
  });

  it('refills tokens over time', () => {
    const rl = createRateLimiter({ capacity: 2, windowMs: 60_000 });
    rl.check('a');
    rl.check('a');
    expect(rl.check('a').ok).toBe(false);
    vi.advanceTimersByTime(31_000); // ~1 token refilled
    expect(rl.check('a').ok).toBe(true);
  });

  it('isolates buckets per key', () => {
    const rl = createRateLimiter({ capacity: 1, windowMs: 60_000 });
    expect(rl.check('alice').ok).toBe(true);
    expect(rl.check('bob').ok).toBe(true);
    expect(rl.check('alice').ok).toBe(false);
    expect(rl.check('bob').ok).toBe(false);
  });
});
